import { adminDb } from "../../../lib/firebase-admin";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const body = await req.json();

    const { orderId } = body;

    await adminDb.collection("orders").doc(orderId).update({
      status: "Canceled",
    });

    return NextResponse.json({
      success: true,
    });
  } catch (e) {
    return NextResponse.json(
      {
        success: false,
      },
      {
        status: 500,
      }
    );
  }
}