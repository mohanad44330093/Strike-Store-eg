"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";

export default function ConfirmOrderPage() {
  const searchParams = useSearchParams();

  const orderId = searchParams.get("id");

  const [status, setStatus] = useState("loading");

  useEffect(() => {
    const confirmOrder = async () => {
      if (!orderId) {
        setStatus("error");
        return;
      }

      try {
        const res = await fetch("/api/confirm-order", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            orderId,
          }),
        });

        if (res.ok) {
          setStatus("success");
        } else {
          setStatus("error");
        }
      } catch {
        setStatus("error");
      }
    };

    confirmOrder();
  }, [orderId]);

  return (
    <div
      style={{
        width: "100%",
        height: "100vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        background: "#0f0f0f",
        color: "white",
        fontFamily: "sans-serif",
        textAlign: "center",
        padding: "20px",
      }}
    >
      {status === "loading" && <h1>Confirming Order...</h1>}

      {status === "success" && (
        <div>
          <h1>✅ Order Confirmed Successfully</h1>
          <p>The order status has been updated.</p>
        </div>
      )}

      {status === "error" && (
        <div>
          <h1>❌ Error</h1>
          <p>Unable to confirm this order.</p>
        </div>
      )}
    </div>
  );
}